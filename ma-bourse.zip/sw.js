/* Ma Bourse — service worker : l'application s'ouvre même sans réseau.
   Pages et données : réseau d'abord (cours frais), copie locale si hors ligne.
   Styles, scripts, icônes : copie locale tout de suite, mise à jour en arrière-plan. */
const CACHE = "ma-bourse-v1";
const SHELL = [
  "./", "index.html", "actualites.html", "bases.html", "simulateur.html",
  "assets/style.css", "assets/app.js", "assets/home.js", "assets/news.js", "assets/guide.js", "assets/sim.js",
  "assets/favicon.svg", "assets/apple-touch-icon.png", "assets/icon-192.png",
  "data/marche.json", "data/historique.json", "data/actualites.json", "data/tendances.json",
  "site.webmanifest"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys()
    .then((keys) => Promise.all(keys.filter((k) => k.startsWith("ma-bourse-") && k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});

const networkFirst = async (req) => {
  const cache = await caches.open(CACHE);
  try {
    const res = req.mode === "navigate" ? await fetch(req) : await fetch(req, {cache: "no-cache"});
    if (res.ok) cache.put(req, res.clone());
    return res;
  } catch (err) {
    const hit = await cache.match(req, {ignoreSearch: true});
    if (hit) return hit;
    if (req.mode === "navigate") return (await cache.match("index.html")) || Response.error();
    throw err;
  }
};

const staleWhileRevalidate = async (req) => {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  const fresh = fetch(req).then((res) => { if (res.ok || res.type === "opaque") cache.put(req, res.clone()); return res; }).catch(() => null);
  return hit || (await fresh) || Response.error();
};

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) {
    // polices Google : copie locale pour le mode hors ligne
    if (/fonts\.(googleapis|gstatic)\.com$/.test(url.hostname)) e.respondWith(staleWhileRevalidate(req));
    return;
  }
  if (req.mode === "navigate" || url.pathname.endsWith(".html") || url.pathname.includes("/data/")) {
    e.respondWith(networkFirst(req));
  } else {
    e.respondWith(staleWhileRevalidate(req));
  }
});
