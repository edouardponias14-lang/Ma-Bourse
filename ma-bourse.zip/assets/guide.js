/* ===== Page Les bases ===== */
(function () {
  "use strict";
  const MB = window.MB, $ = MB.$, $$ = MB.$$, el = MB.el;
  const COLORS = ["", "#10b981", "#14b8a6", "#eab308", "#f97316", "#ef4444"];

  MB.load("marche").then((m) => {
    const rows = m.valeurs.slice().sort((a, b) => a.volatilite_pct - b.volatilite_pct);
    const max = Math.max(...rows.map((r) => r.volatilite_pct));
    const tb = $("#risque-body");
    tb.replaceChildren(...rows.map((r, i) => {
      const bar = el("i"); bar.style.background = COLORS[r.risque_niveau]; bar.dataset.w = (100 * r.volatilite_pct / max).toFixed(1) + "%";
      return el("tr", null,
        el("td", {class: "muted num", text: String(i + 1)}),
        el("td", null, el("div", {class: "name-cell"}, MB.avatar(r), el("div", null, el("span", {text: r.nom}), el("span", {class: "sub", text: r.type + " · " + r.pays})))),
        el("td", {class: "r num", text: MB.n1(r.volatilite_pct) + " %"}),
        el("td", null, el("div", {class: "bar", role: "presentation"}, bar)),
        el("td", {class: "r num down", text: MB.pct(r.pire_baisse_pct, 1)}),
        el("td", null, MB.riskBadge(r)));
    }));
    MB.onVisible(tb, () => requestAnimationFrame(() => $$(".bar > i", tb).forEach((b, i) => { b.style.transitionDelay = i * 0.04 + "s"; b.style.width = b.dataset.w; })));
    // exemples cités dans le texte
    const nv = m.valeurs.find((r) => r.symbole === "NVDA");
    $$("[data-k=nvda3m]").forEach((e) => { if (nv) e.textContent = MB.pct(nv.var_3mois_pct, 1); });
  }).catch(() => {});

  /* sommaire : section active */
  const links = $$(".toc a");
  if (links.length && "IntersectionObserver" in window) {
    const map = new Map(links.map((a) => [a.getAttribute("href").slice(1), a]));
    const o = new IntersectionObserver((ents) => {
      ents.forEach((e) => { if (e.isIntersecting) { links.forEach((a) => a.classList.remove("active")); const a = map.get(e.target.id); if (a) a.classList.add("active"); } });
    }, {rootMargin: "-20% 0px -70% 0px"});
    map.forEach((_a, id) => { const s = document.getElementById(id); if (s) o.observe(s); });
  }
})();
