/* ===== Page d'accueil : marchés ===== */
(function () {
  "use strict";
  const MB = window.MB, $ = MB.$, $$ = MB.$$, el = MB.el;
  const st = {market: "all", sort: "", q: "", sel: "AAPL", period: "3m"};

  Promise.all([MB.load("marche"), MB.load("historique")]).then(([m, h]) => {
    const V = m.valeurs, bySym = new Map(V.map((r) => [r.symbole, r]));

    /* --- phrase d'accroche --- */
    const fillChg = (sel, sym) => $$(sel).forEach((e) => { const r = bySym.get(sym); e.textContent = MB.pct(r.var_jour_pct); e.className = "num " + MB.cls(r.var_jour_pct); });
    fillChg("[data-k=cac]", "^FCHI"); fillChg("[data-k=sp]", "^GSPC");
    const acts = V.filter((r) => r.type === "Action").slice().sort((a, b) => b.var_3mois_pct - a.var_3mois_pct);
    const best = acts[0], worst = acts[acts.length - 1];
    $$("[data-k=best]").forEach((e) => e.replaceChildren(el("strong", {text: best.nom}), " (", el("span", {class: "up num", text: MB.pct(best.var_3mois_pct, 1)}), ")"));
    $$("[data-k=worst]").forEach((e) => e.replaceChildren(el("strong", {text: worst.nom}), " (", el("span", {class: "down num", text: MB.pct(worst.var_3mois_pct, 1)}), ")"));
    $$(".skel").forEach((e) => e.classList.remove("skel"));

    /* --- cartes indices --- */
    $$("[data-index]").forEach((card) => {
      const r = bySym.get(card.dataset.index);
      if (!r) return;
      const v = $(".value", card), c = $(".chip", card), sp = $(".spark", card);
      MB.onVisible(card, () => {
        MB.countUp(v, r.cours, (x) => (r.type === "Indice" ? MB.n2(x) : MB.money(x, r.devise)));
        c.textContent = (r.var_jour_pct >= 0 ? "▲ " : "▼ ") + MB.pct(r.var_jour_pct);
        c.className = "chip " + MB.cls(r.var_jour_pct);
        MB.spark(sp, h.quotidien[r.symbole] || []);
      });
    });

    /* --- tableau des cours --- */
    const tbody = $("#cours-body");
    const renderTable = () => {
      let rows = V.filter((r) => st.market === "all" ? true : st.market === "fonds" ? r.type !== "Action" : r.pays === st.market && r.type === "Action");
      if (st.q) { const q = st.q.toLowerCase(); rows = rows.filter((r) => (r.nom + " " + r.secteur + " " + r.symbole).toLowerCase().includes(q)); }
      if (st.sort) rows = rows.slice().sort((a, b) => st.sort === "volatilite_pct" ? a[st.sort] - b[st.sort] : b[st.sort] - a[st.sort]);
      tbody.replaceChildren(...rows.map((r) => {
        const tr = el("tr", {class: "clickable" + (r.symbole === st.sel ? " sel" : ""), tabindex: "0", "aria-label": "Voir la courbe de " + r.nom},
          el("td", null, el("div", {class: "name-cell"}, MB.avatar(r), el("div", null, el("span", {text: r.nom}), el("span", {class: "sub", text: r.secteur})))),
          el("td", {class: "r num", text: MB.price(r)}),
          ...["var_jour_pct", "var_3mois_pct", "var_1an_pct"].map((k) => el("td", {class: "r num " + MB.cls(r[k]), text: MB.pct(r[k])})),
          el("td", null, MB.riskBadge(r)));
        const pick = () => { st.sel = r.symbole; renderTable(); renderDetail(true); $("#zoom").scrollIntoView({behavior: MB.reduced ? "auto" : "smooth", block: "start"}); };
        tr.addEventListener("click", pick);
        tr.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
        return tr;
      }));
      $("#cours-vide").hidden = rows.length > 0;
    };
    $$("#seg-market button").forEach((b) => b.addEventListener("click", () => {
      $$("#seg-market button").forEach((o) => o.setAttribute("aria-pressed", String(o === b)));
      st.market = b.dataset.v; renderTable();
    }));
    $("#tri").addEventListener("change", (e) => { st.sort = e.target.value; renderTable(); });
    $("#recherche").addEventListener("input", (e) => { st.q = e.target.value.trim(); renderTable(); });
    renderTable();

    /* --- zoom sur une valeur --- */
    const sel = $("#zoom-select");
    sel.replaceChildren(...V.map((r) => new Option(r.nom, r.symbole)));
    sel.addEventListener("change", () => { st.sel = sel.value; renderTable(); renderDetail(true); });
    $$("#seg-period button").forEach((b) => b.addEventListener("click", () => {
      $$("#seg-period button").forEach((o) => o.setAttribute("aria-pressed", String(o === b)));
      st.period = b.dataset.v; renderDetail(true);
    }));
    const chart = $("#zoom-chart");
    const renderDetail = () => {
      const r = bySym.get(st.sel);
      sel.value = st.sel;
      const unit = r.type === "Indice" ? " pts" : r.devise === "USD" ? " $" : " €";
      const vals = st.period === "3m"
        ? (h.quotidien[r.symbole] || []).map((p) => ({x: MB.parseDay(p[0]), y: p[1]}))
        : (h.mensuel[r.symbole] || []).map((p) => ({x: MB.parseMonth(p[0]), y: p[1]}));
      const up = vals.length > 1 && vals[vals.length - 1].y >= vals[0].y;
      MB.lineChart(chart, {
        label: "Cours de " + r.nom + (st.period === "3m" ? " sur trois mois" : " sur cinq ans") + (up ? ", en hausse" : ", en baisse"),
        series: [{name: "", color: up ? "#10b981" : "#ef4444", values: vals, area: true}],
        yFmt: (v) => MB.n0(v), xFmt: st.period === "3m" ? MB.dayShort : MB.monthShort,
        tipX: st.period === "3m" ? MB.dayLong : (d) => "Fin " + MB.monthLong(d), tipY: (v) => MB.n2(v) + unit, height: 320
      });
      $("#zoom-name").textContent = r.nom;
      $("#zoom-sub").textContent = r.type + " · " + r.secteur + " · " + r.pays;
      $("#zoom-avatar").replaceChildren(MB.avatar(r));
      $("#zoom-price").textContent = MB.price(r);
      const setF = (k, txt, cls) => { const d = $(`[data-f="${k}"]`); if (d) { d.textContent = txt; d.className = cls || ""; } };
      for (const k of ["var_jour_pct", "var_3mois_pct", "var_1an_pct", "var_depuis_debut_pct"]) setF(k, MB.pct(r[k]), MB.cls(r[k]));
      setF("volatilite_pct", MB.n1(r.volatilite_pct) + " %");
      setF("pire_baisse_pct", MB.pct(r.pire_baisse_pct, 1), "down");
      const rk = $(`[data-f="risque"]`); if (rk) rk.replaceChildren(MB.riskBadge(r));
    };
    MB.onVisible(chart, renderDetail);

    /* --- aperçu des tendances --- */
    MB.load("tendances").then((t) => {
      const box = $("#tendances-apercu"); if (!box) return;
      const tones = {positif: "Plutôt positif", negatif: "Plutôt négatif", neutre: "À surveiller"};
      box.replaceChildren(...t.tendances.slice(0, 3).map((r, i) => {
        const c = el("article", {class: "card card-hover trend reveal"},
          el("span", {class: "tone " + r.tonalite, text: tones[r.tonalite] || r.tonalite}),
          el("h3", {text: r.titre}), el("p", {class: "muted", text: r.resume}));
        c.style.setProperty("--d", i * 0.1 + "s"); return c;
      }));
      MB.reveal(box);
    }).catch(() => {});
  }).catch(() => {
    $$("[data-erreur]").forEach((e) => { e.hidden = false; });
  });
})();
