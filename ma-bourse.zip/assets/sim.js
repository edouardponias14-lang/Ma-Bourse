/* ===== Simulateur : portefeuille fictif ===== */
(function () {
  "use strict";
  const MB = window.MB, $ = MB.$, $$ = MB.$$, el = MB.el;
  const CAPITAL = 10000, BENCH = "CW8.PA", KEY = "mb-portefeuille";
  const st = {stock: "AAPL", month: "2023-01", dca: false, positions: MB.store.get(KEY, [])};
  if (!Array.isArray(st.positions)) st.positions = [];
  const save = () => MB.store.set(KEY, st.positions);

  Promise.all([MB.load("marche"), MB.load("historique")]).then(([m, h]) => {
    const V = m.valeurs.filter((r) => r.type !== "Indice");
    const info = new Map(m.valeurs.map((r) => [r.symbole, r]));
    const px = new Map(), raw = new Map();
    for (const sym in h.mensuel) {
      px.set(sym, new Map(h.mensuel[sym].map((p) => [p[0], p[2]])));
      raw.set(sym, new Map(h.mensuel[sym].map((p) => [p[0], p[1]])));
    }
    const fx = new Map(Object.entries(h.eurusd));
    const months = Array.from(px.get(BENCH).keys()).sort();
    const last = months[months.length - 1];
    st.positions = st.positions.filter((p) => px.has(p.sym) && months.includes(p.start) && p.amount > 0);

    const lots = (p) => (p.dca ? months.filter((mo) => mo >= p.start).map((mo) => ({mo, eur: p.amount})) : [{mo: p.start, eur: p.amount}]);
    const posAt = (p, at, sym = p.sym) => {
      const P = px.get(sym), cur = (info.get(sym) || {}).devise;
      let inv = 0, val = 0;
      for (const l of lots(p)) {
        if (l.mo > at) continue;
        const pb = P.get(l.mo), pn = P.get(at), fb = fx.get(l.mo), fn = fx.get(at);
        if (!pb || !pn) continue;
        const shares = cur === "USD" ? (l.eur * fb) / pb : l.eur / pb;
        inv += l.eur; val += cur === "USD" ? (shares * pn) / fn : shares * pn;
      }
      return {inv, val};
    };
    const totals = () => {
      let inv = 0, val = 0, bench = 0;
      for (const p of st.positions) { const r = posAt(p, last); inv += r.inv; val += r.val; bench += posAt(p, last, BENCH).val; }
      return {inv, val, bench, cash: CAPITAL - inv, total: CAPITAL - inv + val, gain: val - inv, benchGain: bench - inv};
    };

    /* --- formulaire --- */
    const sStock = $("#sim-stock"), sMonth = $("#sim-mois"), amount = $("#sim-montant");
    sStock.replaceChildren(...V.map((r) => new Option(r.nom + " — " + r.risque, r.symbole)));
    sStock.value = st.stock;
    sMonth.replaceChildren(...months.slice().reverse().map((mo, i) => new Option((i === 0 ? "Aujourd'hui (" : "Fin ") + MB.monthLong(MB.parseMonth(mo)) + (i === 0 ? ")" : ""), mo)));
    sMonth.value = st.month;
    const preview = () => {
      const p = raw.get(st.stock).get(st.month), r = info.get(st.stock);
      $("#sim-prix").textContent = p ? MB.money(p, r.devise) : "—";
      $("#sim-prix-now").textContent = MB.price(r);
    };
    sStock.addEventListener("change", () => { st.stock = sStock.value; preview(); });
    sMonth.addEventListener("change", () => { st.month = sMonth.value; preview(); });
    $$("#seg-dca button").forEach((b) => b.addEventListener("click", () => {
      $$("#seg-dca button").forEach((o) => o.setAttribute("aria-pressed", String(o === b)));
      st.dca = b.dataset.v === "monthly";
      $("#dca-hint").hidden = !st.dca;
    }));
    preview();

    const msg = $("#sim-msg");
    const say = (txt, cls) => { msg.textContent = txt; msg.className = "msg " + (cls || ""); };

    $("#sim-acheter").addEventListener("click", () => {
      const a = Math.round(Number(amount.value));
      if (!(a >= 10)) { say("Entrez un montant d'au moins 10 €.", "down"); return; }
      const p = {sym: st.stock, start: st.month, amount: a, dca: st.dca};
      const need = lots(p).reduce((s, l) => s + l.eur, 0);
      const t = totals();
      if (need > t.cash + 0.01) {
        say(`Il vous faut ${MB.eur(need)} mais il ne reste que ${MB.eur(t.cash)} d'argent fictif. Baissez le montant ou retirez une ligne.`, "down");
        return;
      }
      st.positions.push(p); save();
      const r = posAt(p, last);
      const g = r.val - r.inv;
      say(`${info.get(p.sym).nom} ajouté : ${MB.eur(r.inv)} investis vaudraient aujourd'hui ${MB.eur(r.val)} (${MB.eurS(g)}).`, MB.cls(g));
      render(true);
      if (g > 0) confetti();
    });
    $("#sim-exemple").addEventListener("click", () => {
      st.positions = [
        {sym: "CW8.PA", start: "2022-01", amount: 3000, dca: false},
        {sym: "AAPL", start: "2023-01", amount: 1500, dca: false},
        {sym: "MC.PA", start: "2023-01", amount: 1500, dca: false},
        {sym: "KO", start: "2022-06", amount: 1000, dca: false},
        {sym: "NVDA", start: "2024-06", amount: 1000, dca: false},
        {sym: "TTE.PA", start: "2025-01", amount: 50, dca: true}
      ].filter((p) => px.has(p.sym) && months.includes(p.start));
      save(); say("Portefeuille exemple chargé : 6 lignes variées, dont un achat chaque mois.", ""); render(true);
    });
    $("#sim-reset").addEventListener("click", () => { st.positions = []; save(); say("Portefeuille remis à zéro : vous avez de nouveau 10 000 € fictifs.", ""); render(true); });

    /* --- affichage --- */
    const render = (animate) => {
      const t = totals(), has = st.positions.length > 0;
      const set = (id, v, fmt, colored) => {
        const e = $(id); if (!e) return;
        e.className = "k-value num " + (colored && has ? MB.cls(v) : "");
        if (animate) MB.countUp(e, v, fmt, 800); else e.textContent = fmt(v);
      };
      set("#k-total", t.total, MB.eur);
      set("#k-gain", has ? t.gain : 0, has ? MB.eurS : MB.eur, true);
      set("#k-inv", t.inv, MB.eur);
      set("#k-bench", has ? t.benchGain : 0, has ? MB.eurS : MB.eur, true);
      $("#k-gainpct").textContent = MB.pct(t.inv ? (100 * t.gain) / t.inv : 0, 1) + " sur l'argent investi";
      $("#k-cash").textContent = "Reste disponible : " + MB.eur(t.cash);

      const v = $("#verdict");
      v.className = "verdict " + (!has ? "none" : t.gain >= 0 ? "gain" : "loss");
      $$("[data-verdict]").forEach((e) => { e.hidden = e.dataset.verdict !== (!has ? "none" : t.gain >= 0 ? "gain" : "loss"); });
      const cmp = $("#compare");
      if (has && Math.abs(t.gain - t.benchGain) >= 1) {
        cmp.hidden = false;
        cmp.textContent = t.gain > t.benchGain
          ? `Vous battez l'ETF MSCI World de ${MB.eur(t.gain - t.benchGain)}. Bravo ! Vérifiez quand même que ce n'est pas au prix d'un risque beaucoup plus élevé.`
          : `L'ETF MSCI World aurait fait ${MB.eur(t.benchGain - t.gain)} de mieux. C'est le cas de la majorité des investisseurs, même professionnels, sur le long terme.`;
      } else cmp.hidden = true;
      if (animate) v.classList.remove("pop"), void v.offsetWidth, v.classList.add("pop");

      $("#sim-detail").hidden = !has;
      if (!has) return;

      // lignes
      $("#sim-body").replaceChildren(...st.positions.map((p, i) => {
        const r = posAt(p, last), g = r.val - r.inv, gp = r.inv ? (100 * g) / r.inv : 0, inf = info.get(p.sym);
        const when = MB.monthLong(MB.parseMonth(p.start));
        const btn = el("button", {type: "button", class: "btn btn-ghost btn-sm", "aria-label": "Retirer " + inf.nom, text: "Retirer"});
        btn.addEventListener("click", () => { st.positions.splice(i, 1); save(); say(inf.nom + " retiré du portefeuille.", ""); render(true); });
        return el("tr", null,
          el("td", null, el("div", {class: "name-cell"}, MB.avatar(inf), el("div", null, el("span", {text: inf.nom}), el("span", {class: "sub", text: inf.risque})))),
          el("td", {text: p.dca ? MB.eur(p.amount) + "/mois depuis " + when : "Fin " + when}),
          el("td", {class: "r num", text: MB.eur(r.inv)}),
          el("td", {class: "r num", text: MB.eur(r.val)}),
          el("td", {class: "r num " + MB.cls(g), text: MB.eurS(g)}),
          el("td", {class: "r num " + MB.cls(gp), text: MB.pct(gp, 1)}),
          el("td", {class: "r"}, btn));
      }));

      // courbe
      const start = st.positions.reduce((a, p) => (p.start < a ? p.start : a), last);
      const ms = months.filter((mo) => mo >= start);
      const mine = [], bench = [], inv = [];
      for (const mo of ms) {
        let a = 0, b = 0, c = 0;
        for (const p of st.positions) { const r = posAt(p, mo); a += r.val; c += r.inv; b += posAt(p, mo, BENCH).val; }
        const x = MB.parseMonth(mo); mine.push({x, y: a}); bench.push({x, y: b}); inv.push({x, y: c});
      }
      const chart = $("#sim-chart");
      if (ms.length < 2) { chart.replaceChildren(el("p", {class: "muted", text: "La courbe apparaîtra dès qu'un achat date d'au moins un mois."})); return; }
      MB.lineChart(chart, {
        label: "Valeur du portefeuille fictif depuis " + MB.monthLong(MB.parseMonth(start)),
        series: [
          {name: "Vos placements", color: "var(--chart-1)", values: mine, area: true},
          {name: "ETF MSCI World", color: "var(--chart-2)", values: bench},
          {name: "Argent investi", color: "var(--muted)", values: inv, dash: "5 4", width: 1.5}
        ],
        yFmt: (v) => MB.n0(v) + " €", xFmt: MB.monthShort, tipX: (d) => "Fin " + MB.monthLong(d), tipY: MB.eur, height: 320
      });
    };
    render(false);
  }).catch(() => { const e = $("#sim-msg"); if (e) e.textContent = "Les données n'ont pas pu être chargées. Réessayez dans un instant."; });

  function confetti() {
    if (MB.reduced) return;
    const box = el("div", {class: "confetti", "aria-hidden": "true"});
    const cols = ["#10b981", "#6366f1", "#f59e0b", "#ec4899", "#0ea5e9"];
    for (let i = 0; i < 60; i++) {
      const c = el("i");
      c.style.left = Math.random() * 100 + "%";
      c.style.background = cols[i % cols.length];
      c.style.animationDelay = Math.random() * 0.5 + "s";
      c.style.animationDuration = 1.2 + Math.random() * 1.2 + "s";
      box.append(c);
    }
    document.body.append(box);
    setTimeout(() => box.remove(), 3000);
  }
})();
