/* ===== Ma Bourse — scripts du site ===== */
(function () {
  "use strict";
  document.documentElement.classList.remove("no-js");
  const MB = (window.MB = {});
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  MB.reduced = reduced;

  /* ---------- stockage local (protégé) ---------- */
  MB.store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* stockage indisponible */ } }
  };

  /* ---------- formats français ---------- */
  const nf = (d) => new Intl.NumberFormat("fr-FR", {minimumFractionDigits: d, maximumFractionDigits: d});
  const F0 = nf(0), F1 = nf(1), F2 = nf(2);
  MB.n0 = (v) => F0.format(v); MB.n1 = (v) => F1.format(v); MB.n2 = (v) => F2.format(v);
  MB.sign = (v) => (v > 0 ? "+" : v < 0 ? "−" : "");
  MB.pct = (v, d = 2) => MB.sign(v) + (d === 1 ? F1 : F2).format(Math.abs(v)) + " %";
  MB.eur = (v) => F0.format(Math.round(v)) + " €";
  MB.eurS = (v) => MB.sign(Math.round(v)) + F0.format(Math.abs(Math.round(v))) + " €";
  MB.money = (v, cur) => F2.format(v) + (cur === "USD" ? " $" : cur === "EUR" ? " €" : "");
  MB.price = (r) => (r.type === "Indice" ? F2.format(r.cours) + " pts" : MB.money(r.cours, r.devise));
  MB.cls = (v) => (v > 0 ? "up" : v < 0 ? "down" : "");
  const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  const MOIS_C = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  MB.MOIS = MOIS; MB.MOIS_C = MOIS_C;
  MB.parseDay = (s) => new Date(s + "T00:00:00Z");
  MB.parseMonth = (s) => new Date(s + "-01T00:00:00Z");
  MB.dayLong = (d) => d.getUTCDate() + " " + MOIS[d.getUTCMonth()] + " " + d.getUTCFullYear();
  MB.dayShort = (d) => d.getUTCDate() + " " + MOIS_C[d.getUTCMonth()];
  MB.monthLong = (d) => MOIS[d.getUTCMonth()] + " " + d.getUTCFullYear();
  MB.monthShort = (d) => MOIS_C[d.getUTCMonth()] + " " + String(d.getUTCFullYear()).slice(2);

  /* ---------- petits utilitaires DOM ---------- */
  MB.$ = (s, r = document) => r.querySelector(s);
  MB.$$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  MB.el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      if (attrs[k] == null || attrs[k] === false) continue;
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else e.setAttribute(k, attrs[k]);
    }
    for (const k of kids) if (k != null) e.append(k);
    return e;
  };
  const PALETTE = ["#6366f1", "#10b981", "#f59e0b", "#ec4899", "#0ea5e9", "#8b5cf6", "#14b8a6", "#ef4444", "#84cc16", "#f97316"];
  MB.color = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return PALETTE[h % PALETTE.length]; };
  MB.avatar = (r) => {
    const txt = r.type === "Indice" ? (r.symbole === "^FCHI" ? "40" : "500") : r.nom.replace(/[^A-Za-zÀ-ÿ]/g, "").slice(0, 2).toUpperCase();
    const a = MB.el("span", {class: "avatar", "aria-hidden": "true", text: txt});
    a.style.background = `linear-gradient(135deg, ${MB.color(r.symbole)}, ${MB.color(r.symbole + "x")})`;
    return a;
  };
  MB.riskBadge = (r) => MB.el("span", {class: "risk r" + r.risque_niveau, text: r.risque});

  /* ---------- données ---------- */
  const cache = {};
  MB.load = (name) => (cache[name] = cache[name] || fetch("data/" + name + ".json", {cache: "no-cache"}).then((r) => {
    if (!r.ok) throw new Error(name + " : " + r.status);
    return r.json();
  }));

  /* ---------- thème clair / sombre ---------- */
  const root = document.documentElement;
  const sysDark = () => window.matchMedia("(prefers-color-scheme: dark)").matches;
  const isDark = () => root.getAttribute("data-theme") ? root.getAttribute("data-theme") === "dark" : sysDark();
  const themeBtn = MB.$("#theme-toggle");
  const syncThemeBtn = () => { if (themeBtn) themeBtn.setAttribute("aria-label", isDark() ? "Passer en mode clair" : "Passer en mode sombre"); };
  if (themeBtn) themeBtn.addEventListener("click", () => {
    const t = isDark() ? "light" : "dark";
    root.setAttribute("data-theme", t); MB.store.set("mb-theme", t); syncThemeBtn();
    document.dispatchEvent(new CustomEvent("mb:theme"));
  });
  syncThemeBtn();

  /* ---------- navigation ---------- */
  const burger = MB.$("#burger"), links = MB.$("#nav-links");
  if (burger && links) burger.addEventListener("click", () => {
    const open = links.classList.toggle("open");
    burger.setAttribute("aria-expanded", String(open));
  });
  const header = MB.$(".site-header"), toTop = MB.$("#to-top");
  const onScroll = () => {
    const y = window.scrollY;
    if (header) header.classList.toggle("scrolled", y > 8);
    if (toTop) toTop.classList.toggle("show", y > 700);
  };
  window.addEventListener("scroll", onScroll, {passive: true}); onScroll();
  if (toTop) toTop.addEventListener("click", () => window.scrollTo({top: 0, behavior: reduced ? "auto" : "smooth"}));

  /* ---------- apparition au défilement ---------- */
  const io = "IntersectionObserver" in window ? new IntersectionObserver((ents) => {
    for (const e of ents) if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); e.target.dispatchEvent(new CustomEvent("mb:in")); }
  }, {rootMargin: "0px 0px -8% 0px", threshold: 0.08}) : null;
  MB.reveal = (scope = document) => MB.$$(".reveal:not(.in)", scope).forEach((el) => (io ? io.observe(el) : el.classList.add("in")));
  MB.onVisible = (el, fn) => {
    if (!io || reduced) { fn(); return; }
    const o = new IntersectionObserver((ents) => { if (ents.some((e) => e.isIntersecting)) { o.disconnect(); fn(); } }, {threshold: 0.15});
    o.observe(el);
  };
  MB.reveal();

  /* ---------- compteur animé ---------- */
  MB.countUp = (el, value, fmt, dur = 1100) => {
    if (reduced || !isFinite(value)) { el.textContent = fmt(value); return; }
    const from = Number(el.dataset.v || 0); el.dataset.v = value;
    const t0 = performance.now();
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(from + (value - from) * e);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  /* ---------- graphique en courbes (SVG) ---------- */
  const NS = "http://www.w3.org/2000/svg";
  const svgEl = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
  const niceTicks = (min, max, n) => {
    const span = max - min || Math.abs(max) || 1;
    const step0 = span / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
    const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => span / s <= n) || 10 * mag;
    const out = []; for (let v = Math.ceil(min / step) * step; v <= max + 1e-9; v += step) out.push(+v.toFixed(10));
    return out;
  };
  MB.lineChart = (el, cfg) => {
    const draw = (animate) => {
      const W = Math.max(260, el.clientWidth), H = cfg.height || 300;
      el.replaceChildren();
      const all = cfg.series.flatMap((s) => s.values);
      if (!all.length) return;
      const xs = all.map((d) => +d.x), ys = all.map((d) => d.y);
      let x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      const pad = (y1 - y0) * 0.1 || Math.abs(y1) * 0.05 || 1; y0 -= pad; y1 += pad;
      const ticks = niceTicks(y0, y1, W < 420 ? 4 : 5);
      y0 = Math.min(y0, ticks[0]); y1 = Math.max(y1, ticks[ticks.length - 1]);
      const svg = svgEl("svg", {width: W, height: H, viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": cfg.label});
      el.append(svg);
      // largeur des étiquettes
      const probe = svgEl("text", {x: 0, y: -10}); svg.append(probe);
      let ml = 0; for (const t of ticks) { probe.textContent = cfg.yFmt(t); ml = Math.max(ml, probe.getComputedTextLength()); }
      probe.remove();
      const m = {t: 12, r: 12, b: 30, l: Math.ceil(ml) + 12};
      const X = (v) => m.l + ((v - x0) / (x1 - x0 || 1)) * (W - m.l - m.r);
      const Y = (v) => H - m.b - ((v - y0) / (y1 - y0 || 1)) * (H - m.t - m.b);
      const gy = svgEl("g", {class: "grid-y"}); svg.append(gy);
      for (const t of ticks) {
        gy.append(svgEl("line", {x1: m.l, x2: W - m.r, y1: Y(t), y2: Y(t)}));
        const tx = svgEl("text", {x: m.l - 8, y: Y(t) + 4, "text-anchor": "end"}); tx.textContent = cfg.yFmt(t); gy.append(tx);
      }
      // axe X
      const nX = Math.max(2, Math.min(6, Math.floor((W - m.l - m.r) / 95)));
      for (let i = 0; i < nX; i++) {
        const v = x0 + ((x1 - x0) * i) / (nX - 1);
        const tx = svgEl("text", {x: X(v), y: H - 8, "text-anchor": i === 0 ? "start" : i === nX - 1 ? "end" : "middle"});
        tx.textContent = cfg.xFmt(new Date(v)); svg.append(tx);
      }
      // dégradé d'aire
      const defs = svgEl("defs", {}); svg.append(defs);
      cfg.series.forEach((s, i) => {
        const path = s.values.map((d, j) => (j ? "L" : "M") + X(+d.x).toFixed(1) + "," + Y(d.y).toFixed(1)).join("");
        if (s.area) {
          const id = "g" + Math.random().toString(36).slice(2, 8);
          const lg = svgEl("linearGradient", {id, x1: 0, x2: 0, y1: 0, y2: 1});
          lg.append(svgEl("stop", {offset: "0%", "stop-color": s.color, "stop-opacity": 1}), svgEl("stop", {offset: "100%", "stop-color": s.color, "stop-opacity": 0}));
          defs.append(lg);
          const last = s.values[s.values.length - 1], first = s.values[0];
          svg.append(svgEl("path", {d: path + `L${X(+last.x)},${H - m.b}L${X(+first.x)},${H - m.b}Z`, fill: `url(#${id})`, class: "area" + (animate && !reduced ? " fade-area" : "")}));
        }
        const p = svgEl("path", {d: path, class: "line", stroke: s.color});
        if (s.dash) p.setAttribute("stroke-dasharray", s.dash);
        if (s.width) p.setAttribute("stroke-width", s.width);
        svg.append(p);
        if (animate && !reduced && !s.dash) {
          const len = p.getTotalLength(); p.style.setProperty("--len", len); p.classList.add("draw");
          p.style.animationDelay = i * 0.15 + "s";
        }
      });
      // infobulle
      const tip = MB.el("div", {class: "tip"}); el.append(tip);
      const guide = svgEl("line", {y1: m.t, y2: H - m.b, stroke: "var(--muted)", "stroke-dasharray": "3 3", opacity: 0}); svg.append(guide);
      const dots = cfg.series.map((s) => { const c = svgEl("circle", {r: 5, fill: s.color, stroke: "var(--surface)", "stroke-width": 2, opacity: 0}); svg.append(c); return c; });
      const base = cfg.series[0].values;
      const hit = svgEl("rect", {x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: "transparent"});
      hit.style.touchAction = "pan-y"; svg.append(hit);
      const show = (ev) => {
        const r = svg.getBoundingClientRect(), px = ev.clientX - r.left;
        const xv = x0 + ((px - m.l) / (W - m.l - m.r)) * (x1 - x0);
        let bi = 0, bd = Infinity;
        base.forEach((d, j) => { const dd = Math.abs(+d.x - xv); if (dd < bd) { bd = dd; bi = j; } });
        const xt = +base[bi].x;
        guide.setAttribute("x1", X(xt)); guide.setAttribute("x2", X(xt)); guide.setAttribute("opacity", 1);
        tip.replaceChildren(MB.el("b", {text: cfg.tipX(new Date(xt))}));
        cfg.series.forEach((s, i) => {
          const d = s.values.find((v) => +v.x === xt);
          dots[i].setAttribute("opacity", d ? 1 : 0);
          if (!d) return;
          dots[i].setAttribute("cx", X(xt)); dots[i].setAttribute("cy", Y(d.y));
          const dot = MB.el("span", {class: "dot"}); dot.style.background = s.color;
          tip.append(MB.el("div", {class: "row"}, dot, MB.el("span", {text: (s.name ? s.name + " : " : "") + cfg.tipY(d.y)})));
        });
        tip.style.opacity = 1;
        const tw = tip.offsetWidth, left = X(xt) + 14 + tw > W ? X(xt) - tw - 14 : X(xt) + 14;
        tip.style.left = Math.max(0, left) + "px"; tip.style.top = m.t + "px";
      };
      hit.addEventListener("pointermove", show); hit.addEventListener("pointerdown", show);
      hit.addEventListener("pointerleave", () => { tip.style.opacity = 0; guide.setAttribute("opacity", 0); dots.forEach((d) => d.setAttribute("opacity", 0)); });
    };
    el._mbCfg = cfg;
    draw(true);
    if (!el._mbRO && "ResizeObserver" in window) {
      let w = el.clientWidth;
      el._mbRO = new ResizeObserver(() => { if (Math.abs(el.clientWidth - w) > 4) { w = el.clientWidth; if (el._mbRedraw) el._mbRedraw(); } });
      el._mbRO.observe(el);
    }
    el._mbRedraw = () => draw(false);
  };
  document.addEventListener("mb:theme", () => MB.$$(".chart").forEach((c) => c._mbRedraw && c._mbRedraw()));

  MB.spark = (el, vals) => {
    const W = Math.max(120, el.clientWidth), H = el.clientHeight || 56;
    el.replaceChildren();
    if (vals.length < 2) return;
    const ys = vals.map((v) => v[1]), mn = Math.min(...ys), mx = Math.max(...ys);
    const up = ys[ys.length - 1] >= ys[0], col = up ? "var(--up)" : "var(--down)";
    const X = (i) => 2 + (i / (vals.length - 1)) * (W - 4), Y = (v) => H - 4 - ((v - mn) / (mx - mn || 1)) * (H - 8);
    const d = ys.map((v, i) => (i ? "L" : "M") + X(i).toFixed(1) + "," + Y(v).toFixed(1)).join("");
    const svg = svgEl("svg", {width: W, height: H, role: "img", "aria-label": "Évolution sur trois mois, " + (up ? "en hausse" : "en baisse")});
    const id = "s" + Math.random().toString(36).slice(2, 8);
    const defs = svgEl("defs", {}), lg = svgEl("linearGradient", {id, x1: 0, x2: 0, y1: 0, y2: 1});
    lg.append(svgEl("stop", {offset: "0%", "stop-color": up ? "#10b981" : "#ef4444", "stop-opacity": 0.35}), svgEl("stop", {offset: "100%", "stop-color": up ? "#10b981" : "#ef4444", "stop-opacity": 0}));
    defs.append(lg); svg.append(defs);
    svg.append(svgEl("path", {d: d + `L${X(ys.length - 1)},${H}L${X(0)},${H}Z`, fill: `url(#${id})`}));
    const p = svgEl("path", {d, fill: "none", stroke: col, "stroke-width": 2, "stroke-linejoin": "round"});
    svg.append(p); el.append(svg);
    if (!reduced) { const len = p.getTotalLength(); p.style.setProperty("--len", len); p.classList.add("draw"); }
  };

  /* ---------- bandeau défilant + date de mise à jour (toutes pages) ---------- */
  MB.load("marche").then((d) => {
    const track = MB.$("#ticker-track");
    if (track) {
      const items = d.valeurs.map((r) => MB.el("span", {class: "ticker-item"},
        MB.el("b", {text: r.nom}), MB.el("span", {class: "num", text: MB.price(r)}),
        MB.el("span", {class: "num " + MB.cls(r.var_jour_pct), text: (r.var_jour_pct >= 0 ? "▲ " : "▼ ") + MB.pct(r.var_jour_pct)})));
      track.replaceChildren(...items, ...items.map((n) => { const c = n.cloneNode(true); c.setAttribute("aria-hidden", "true"); return c; }));
    }
    MB.$$("[data-maj]").forEach((e) => { e.textContent = MB.dayLong(new Date(d.maj)); });
  }).catch(() => {});
})();

/* ===== Application installable (iPhone, Android, ordinateur) ===== */
(function () {
  "use strict";
  const MB = window.MB;
  const standalone = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const framed = (() => { try { return window.self !== window.top; } catch (e) { return true; } })();
  if (standalone) document.documentElement.classList.add("is-app");

  // service worker : ouverture hors ligne (uniquement sur le vrai site en https)
  if ("serviceWorker" in navigator && !framed && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", () => { navigator.serviceWorker.register("sw.js").catch(() => {}); });
  }
  if (standalone || framed) {
    MB.$$("[data-install]").forEach((b) => { b.closest("li") ? (b.closest("li").hidden = true) : (b.hidden = true); });
    return;
  }

  const ua = navigator.userAgent;
  const isIOS = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  let deferred = null;
  window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferred = e; });

  const SHARE = '<svg class="share" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12M8 7l4-4 4 4"/><path d="M5 11v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8"/></svg>';
  let box = null;
  const close = (remember) => {
    if (!box) return;
    box.classList.remove("show");
    const b = box; box = null; setTimeout(() => b.remove(), 500);
    if (remember) MB.store.set("mb-install-vu", Date.now());
  };
  const open = () => {
    if (box) return;
    box = document.createElement("div");
    box.className = "install" + (isIOS ? "" : " no-arrow");
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-label", "Installer Ma Bourse");
    const how = isIOS
      ? `Touchez ${SHARE} <strong>Partager</strong> en bas de Safari, puis <strong>Sur l'écran d'accueil</strong>.`
      : deferred ? "Ajoutez Ma Bourse à vos applications, en un clic, sans passer par un store."
      : "Ouvrez le menu de votre navigateur et choisissez <strong>Installer l'application</strong> ou <strong>Ajouter à l'écran d'accueil</strong>.";
    box.innerHTML = `<img src="assets/apple-touch-icon.png" alt=""><div><b>Installez Ma Bourse</b><p>${how}</p></div>` +
      `<button type="button" class="x" aria-label="Fermer">✕</button>` +
      (!isIOS && deferred ? `<button type="button" class="btn btn-primary btn-sm" data-go>Installer</button>` : "");
    document.body.append(box);
    box.querySelector(".x").addEventListener("click", () => close(true));
    const go = box.querySelector("[data-go]");
    if (go) go.addEventListener("click", async () => {
      deferred.prompt();
      try { await deferred.userChoice; } catch (e) { /* ignoré */ }
      deferred = null; close(true);
    });
    requestAnimationFrame(() => requestAnimationFrame(() => box && box.classList.add("show")));
  };
  MB.$$("[data-install]").forEach((b) => b.addEventListener("click", open));

  // proposition automatique sur iPhone (Safari), une fois par semaine au plus
  const seen = MB.store.get("mb-install-vu", 0);
  const fresh = Date.now() - seen > 7 * 24 * 3600 * 1000;
  if (fresh && isIOS) setTimeout(open, 4000);
  window.addEventListener("beforeinstallprompt", () => { if (fresh && !isIOS) setTimeout(open, 4000); });
  window.addEventListener("appinstalled", () => close(true));
})();
