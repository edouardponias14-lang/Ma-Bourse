# Ma Bourse

Site pédagogique pour débuter en Bourse : cours des actions les plus connues, actualité expliquée, guide « Les bases » et simulateur avec 10 000 € d'argent fictif.

Le site est fait de fichiers simples (HTML, CSS, JavaScript), sans serveur. Il est hébergé gratuitement sur **GitHub Pages**, et un robot GitHub met les cours à jour tout seul après chaque clôture de la Bourse (du lundi au vendredi).

---

## Mettre le site en ligne (15 minutes environ)

### 1. Créer un compte GitHub
Allez sur <https://github.com/signup> et créez un compte gratuit. Votre **nom d'utilisateur** apparaîtra dans l'adresse du site : `https://votre-pseudo.github.io/ma-bourse/`.

### 2. Créer le dépôt
1. Cliquez sur **New repository** (le bouton « + » en haut à droite, puis « New repository »).
2. Nom : `ma-bourse`. Cochez **Public**. Cliquez sur **Create repository**.

### 3. Envoyer les fichiers
1. Sur la page du dépôt, cliquez sur **uploading an existing file**.
2. Dézippez `ma-bourse.zip` sur votre ordinateur, ouvrez le dossier, sélectionnez **tout son contenu** et glissez-le dans la page GitHub.
3. Cliquez sur **Commit changes**.

> ⚠️ Le dossier caché `.github` (qui contient le robot de mise à jour) n'est souvent pas visible ni envoyé par glisser-déposer. Pour l'ajouter à la main :
> 1. Dans le dépôt, cliquez sur **Add file → Create new file**.
> 2. Dans le nom du fichier, tapez exactement : `.github/workflows/site.yml`
> 3. Copiez-collez le contenu du fichier `site.yml` fourni (dossier `.github/workflows/`), puis **Commit changes**.
>
> Faites de même pour le fichier vide `.nojekyll` si GitHub ne l'a pas pris (nom : `.nojekyll`, contenu vide).

### 4. Activer GitHub Pages
1. Onglet **Settings** du dépôt, puis **Pages** dans le menu de gauche.
2. Sous **Build and deployment → Source**, choisissez **GitHub Actions**.

### 5. Lancer la première publication
1. Onglet **Actions**, cliquez sur **Mettre à jour et publier le site**, puis **Run workflow**.
2. Attendez 1 à 2 minutes (pastille verte ✅). Votre site est en ligne à l'adresse `https://votre-pseudo.github.io/ma-bourse/`.

Ensuite, le robot tourne tout seul deux fois par jour en semaine (après la clôture de Paris et de New York).

> GitHub met en pause les tâches automatiques d'un dépôt resté **60 jours sans modification**. Si les cours ne bougent plus, retournez dans **Actions** et cliquez sur **Enable workflow** ou relancez-le à la main.

---

## Installer Ma Bourse sur un iPhone (comme une application)

Une fois le site en ligne :

1. Ouvrez l'adresse du site dans **Safari** sur l'iPhone.
2. Touchez le bouton **Partager** (le carré avec une flèche vers le haut, en bas de l'écran).
3. Faites défiler et touchez **Sur l'écran d'accueil**, puis **Ajouter**.

L'icône Ma Bourse apparaît sur l'écran d'accueil. L'application s'ouvre en plein écran, sans la barre de Safari, et fonctionne même sans réseau (avec les derniers cours consultés). Le site affiche lui-même une petite bulle qui rappelle ces étapes aux visiteurs sur iPhone.

Sur Android (Chrome) et sur ordinateur (Chrome, Edge), un bouton **Installer** apparaît directement.

> L'installation ne marche que depuis le vrai site en ligne (adresse en `https://`), pas depuis l'aperçu ni un fichier ouvert sur l'ordinateur.

---

## Apparaître sur Google

Google trouve un nouveau site tout seul, mais cela peut prendre des semaines. Pour accélérer :

1. Allez sur **Google Search Console** : <https://search.google.com/search-console>.
2. **Ajouter une propriété → Préfixe d'URL**, et collez l'adresse de votre site (avec le `/` final).
3. Pour prouver que le site est à vous, choisissez **Fichier HTML** : téléchargez le fichier `googlexxxx.html` proposé par Google, envoyez-le à la racine du dépôt (comme à l'étape 3), attendez la publication, puis cliquez sur **Valider**.
4. Dans **Sitemaps**, saisissez `sitemap.xml` et cliquez sur **Envoyer**.
5. Dans **Inspection de l'URL**, collez l'adresse de l'accueil puis **Demander l'indexation**.

Astuces pour mieux remonter dans les résultats :
- partagez le lien (réseaux sociaux, forum, site de votre école…) : chaque lien vers votre site aide Google à le trouver et à lui faire confiance ;
- mettez à jour l'actualité régulièrement : un site vivant est mieux classé ;
- un nom de domaine personnalisé (par ex. `mabourse.fr`, quelques euros par an) fait plus professionnel : ajoutez un fichier `CNAME` contenant le domaine et suivez l'aide GitHub « Configuring a custom domain ».

---

## Mettre à jour le contenu

| Quoi | Où | Comment |
| --- | --- | --- |
| Cours, courbes, classement des risques | `data/marche.json`, `data/historique.json` | Automatique (robot GitHub). |
| Articles de presse | `data/actualites.json` | À la main : modifiez le fichier sur GitHub (icône crayon), ou demandez à Claude de le rafraîchir. |
| Tendances du moment | `data/tendances.json` | À la main, comme ci-dessus. |
| Liste des valeurs suivies | `scripts/update_data.py` (bloc `VALEURS`) | Ajoutez une ligne avec le symbole Yahoo Finance (ex. `"BNP.PA"`). |

Pour tester sur votre ordinateur : dans le dossier du site, lancez `python3 -m http.server` puis ouvrez <http://localhost:8000>. (Ouvrir directement `index.html` en double-cliquant ne charge pas les données.)

---

## Structure

```
index.html          Accueil : indices, cours, zoom sur une valeur
actualites.html     Tendances, hausses/baisses, articles de presse
bases.html          Guide débutant + classement des risques + FAQ
simulateur.html     Portefeuille fictif de 10 000 €
404.html            Page d'erreur
assets/             Style, scripts, icônes, image de partage
sw.js               Mode hors ligne de l'application
site.webmanifest    Nom, icônes et couleurs de l'application installée
data/               Données JSON lues par les pages
scripts/update_data.py   Téléchargement des cours
.github/workflows/site.yml  Robot de mise à jour et de publication
robots.txt, sitemap.xml     Pour Google
```

## Avertissement

Site pédagogique, pas un conseil en investissement. Les cours proviennent de Yahoo Finance via une interface non officielle, prévue pour un usage personnel : pour un site à grosse audience ou commercial, passez à un fournisseur de données sous licence.
