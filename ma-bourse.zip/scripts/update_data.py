#!/usr/bin/env python3
"""Met à jour les données de marché du site Ma Bourse.

Télécharge les cours (Yahoo Finance) des valeurs suivies, calcule les
variations et le niveau de risque, puis écrit les fichiers JSON du dossier
data/. En cas d'échec réseau, les anciens fichiers sont conservés.

Usage : python3 scripts/update_data.py
"""
import datetime as dt
import json
import math
import os
import statistics as st
import sys
import time
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
UTC = dt.timezone.utc

# symbole: (nom, type, pays, secteur, devise)
VALEURS = {
    "CW8.PA": ("Amundi MSCI World (ETF)", "ETF", "Monde", "Fonds indiciel mondial", "EUR"),
    "^GSPC": ("S&P 500", "Indice", "États-Unis", "500 plus grandes entreprises US", "USD"),
    "^FCHI": ("CAC 40", "Indice", "France", "40 plus grandes entreprises françaises", "EUR"),
    "AAPL": ("Apple", "Action", "États-Unis", "Technologie", "USD"),
    "MSFT": ("Microsoft", "Action", "États-Unis", "Logiciels / cloud", "USD"),
    "NVDA": ("Nvidia", "Action", "États-Unis", "Semi-conducteurs / IA", "USD"),
    "AMZN": ("Amazon", "Action", "États-Unis", "Commerce en ligne / cloud", "USD"),
    "GOOGL": ("Alphabet (Google)", "Action", "États-Unis", "Internet / publicité", "USD"),
    "META": ("Meta (Facebook)", "Action", "États-Unis", "Réseaux sociaux", "USD"),
    "TSLA": ("Tesla", "Action", "États-Unis", "Voitures électriques", "USD"),
    "KO": ("Coca-Cola", "Action", "États-Unis", "Boissons", "USD"),
    "JNJ": ("Johnson & Johnson", "Action", "États-Unis", "Santé", "USD"),
    "PG": ("Procter & Gamble", "Action", "États-Unis", "Produits du quotidien", "USD"),
    "MC.PA": ("LVMH", "Action", "France", "Luxe", "EUR"),
    "OR.PA": ("L'Oréal", "Action", "France", "Cosmétiques", "EUR"),
    "TTE.PA": ("TotalEnergies", "Action", "France", "Énergie", "EUR"),
    "AIR.PA": ("Airbus", "Action", "France", "Aéronautique", "EUR"),
    "SAN.PA": ("Sanofi", "Action", "France", "Pharmacie", "EUR"),
}
FX = "EURUSD=X"


def fetch(symbol, rng, interval, tries=3):
    url = ("https://query1.finance.yahoo.com/v8/finance/chart/"
           f"{urllib.parse.quote(symbol)}?range={rng}&interval={interval}")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (MaBourse site updater)"})
    for i in range(tries):
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                return json.load(r)["chart"]["result"][0]
        except Exception as e:  # noqa: BLE001
            if i == tries - 1:
                raise RuntimeError(f"{symbol} {interval}: {e}") from e
            time.sleep(2 * (i + 1))


def monthly(res):
    """{AAAA-MM: (clôture, clôture ajustée)} — la dernière ligne du mois gagne."""
    q = res["indicators"]["quote"][0]["close"]
    adj = res["indicators"].get("adjclose", [{}])[0].get("adjclose") or q
    out = {}
    for i, t in enumerate(res["timestamp"]):
        if q[i] is None:
            continue
        d = dt.datetime.fromtimestamp(t + 12 * 3600, UTC).date()
        out[f"{d.year}-{d.month:02d}"] = (q[i], adj[i] if adj[i] is not None else q[i])
    return dict(sorted(out.items()))


def daily(res):
    q = res["indicators"]["quote"][0]["close"]
    off = res["meta"].get("gmtoffset", 0)
    out = {}
    for i, t in enumerate(res["timestamp"]):
        if q[i] is None:
            continue
        out[dt.datetime.fromtimestamp(t + off, UTC).date().isoformat()] = q[i]
    return sorted(out.items())


def risk(vol):
    for limit, lvl, label in ((15, 1, "Faible"), (22, 2, "Modéré"), (30, 3, "Moyen"), (45, 4, "Élevé")):
        if vol < limit:
            return lvl, label
    return 5, "Très élevé"


def main():
    actions, hist_d, hist_m = [], {}, {}
    latest = None
    for sym, (nom, typ, pays, secteur, devise) in VALEURS.items():
        m = monthly(fetch(sym, "5y", "1mo"))
        dres = fetch(sym, "3mo", "1d")
        d = daily(dres)
        time.sleep(0.4)
        price = dres["meta"].get("regularMarketPrice") or d[-1][1]
        prev = d[-2][1] if len(d) > 1 else price
        months = list(m.keys())
        adj = [m[k][1] for k in months]
        rets = [math.log(adj[i] / adj[i - 1]) for i in range(1, len(adj)) if adj[i - 1] and adj[i]]
        vol = st.stdev(rets) * math.sqrt(12) * 100
        peak, dd = adj[0], 0.0
        for x in adj:
            peak = max(peak, x)
            dd = min(dd, x / peak - 1)
        # cours d'il y a un an : même mois l'an dernier
        last_m = months[-1]
        y, mo = int(last_m[:4]), int(last_m[5:])
        year_ago = f"{y - 1}-{mo:02d}"
        p1a = m.get(year_ago, m[months[max(0, len(months) - 13)]])[0]
        p0 = m[months[0]][0]
        lvl, label = risk(vol)
        t = dt.datetime.fromtimestamp(dres["meta"]["regularMarketTime"], UTC)
        latest = max(latest, t) if latest else t
        actions.append({
            "symbole": sym, "nom": nom, "type": typ, "pays": pays, "secteur": secteur, "devise": devise,
            "cours": round(price, 2), "cloture_veille": round(prev, 2),
            "var_jour_pct": round((price / prev - 1) * 100, 2),
            "var_3mois_pct": round((price / d[0][1] - 1) * 100, 2),
            "var_1an_pct": round((price / p1a - 1) * 100, 2),
            "var_depuis_debut_pct": round((price / p0 - 1) * 100, 2),
            "debut": months[0],
            "volatilite_pct": round(vol, 1), "pire_baisse_pct": round(dd * 100, 1),
            "risque_niveau": lvl, "risque": label,
        })
        hist_d[sym] = [[k, round(v, 4)] for k, v in d]
        hist_m[sym] = [[k, round(c, 4), round(a, 4)] for k, (c, a) in m.items()]
    fx = {k: round(c, 5) for k, (c, _a) in monthly(fetch(FX, "5y", "1mo")).items()}

    os.makedirs(DATA, exist_ok=True)
    stamp = {"maj": latest.strftime("%Y-%m-%dT%H:%M:%SZ"), "source": "Yahoo Finance"}
    write("marche.json", {**stamp, "valeurs": actions})
    write("historique.json", {**stamp, "quotidien": hist_d, "mensuel": hist_m, "eurusd": fx})
    print(f"OK — {len(actions)} valeurs, données du {stamp['maj']}")


def write(name, obj):
    path = os.path.join(DATA, name)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        print(f"Échec de la mise à jour, anciennes données conservées : {e}", file=sys.stderr)
        sys.exit(0)
