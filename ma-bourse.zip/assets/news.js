/* ===== Page Actualités ===== */
(function () {
  "use strict";
  const MB = window.MB, $ = MB.$, el = MB.el;
  const tones = {positif: "Plutôt positif", negatif: "Plutôt négatif", neutre: "À surveiller"};
  const icons = {positif: "▲", negatif: "▼", neutre: "●"};

  MB.load("tendances").then((t) => {
    const box = $("#tendances");
    $("#tendances-date").textContent = MB.dayLong(MB.parseDay(t.maj));
    box.replaceChildren(...t.tendances.map((r, i) => {
      const c = el("article", {class: "card card-hover trend reveal"},
        el("span", {class: "tone " + r.tonalite, text: icons[r.tonalite] + " " + (tones[r.tonalite] || r.tonalite)}),
        el("h3", {text: r.titre}), el("p", {text: r.resume}),
        el("p", {class: "tip-box"}, el("strong", {text: "Pour un débutant : "}), r.a_retenir));
      c.style.setProperty("--d", (i % 3) * 0.1 + "s"); return c;
    }));
    MB.reveal(box);
  }).catch(() => {});

  MB.load("marche").then((m) => {
    const acts = m.valeurs.filter((r) => r.type === "Action").slice().sort((a, b) => b.var_3mois_pct - a.var_3mois_pct);
    const li = (r) => el("li", null, el("span", {class: "name-cell"}, MB.avatar(r), el("span", {text: r.nom})), el("strong", {class: "num " + MB.cls(r.var_3mois_pct), text: MB.pct(r.var_3mois_pct, 1)}));
    $("#hausses").replaceChildren(...acts.slice(0, 4).map(li));
    $("#baisses").replaceChildren(...acts.slice(-4).reverse().map(li));
  }).catch(() => {});

  MB.load("actualites").then((n) => {
    const arts = n.articles.slice().sort((a, b) => (a.date < b.date ? 1 : -1));
    let theme = "";
    const chips = $("#themes"), list = $("#articles");
    const themes = Array.from(new Set(arts.map((a) => a.theme)));
    const renderChips = () => chips.replaceChildren(...["", ...themes].map((t) => {
      const b = el("button", {type: "button", class: "chip-btn", "aria-pressed": String(t === theme), text: t || "Tous les sujets"});
      b.addEventListener("click", () => { theme = t; renderChips(); renderList(); });
      return b;
    }));
    const renderList = () => {
      list.replaceChildren(...arts.filter((a) => !theme || a.theme === theme).map((a, i) => {
        const d = MB.parseDay(a.date);
        const safe = /^https:\/\//.test(a.url || "");
        const title = safe ? el("a", {href: a.url, target: "_blank", rel: "noopener noreferrer", text: a.titre}) : el("span", {text: a.titre});
        const item = el("li", {class: "card news-item reveal"},
          el("div", {class: "news-date", "aria-hidden": "true"}, el("b", {text: String(d.getUTCDate())}), el("span", {text: MB.MOIS_C[d.getUTCMonth()]})),
          el("div", null,
            el("div", {class: "news-meta", text: MB.dayLong(d) + " · " + a.source + " · " + a.theme}),
            el("h3", null, title),
            el("p", {text: a.resume})));
        item.style.setProperty("--d", Math.min(i, 5) * 0.06 + "s");
        return item;
      }));
      MB.reveal(list);
    };
    renderChips(); renderList();
  }).catch(() => {});
})();
